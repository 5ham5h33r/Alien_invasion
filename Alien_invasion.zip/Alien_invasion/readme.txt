In this archive, you'll find a compiled alien_invasion.exe file and some assets essential to run the exe.
Ensure that you have extracted this archive before attempting to run alien_invasion.exe 
Make sure that the "scores" and "images" folder are in the same directory as alien_invasion.exe before attempting to run the executable.